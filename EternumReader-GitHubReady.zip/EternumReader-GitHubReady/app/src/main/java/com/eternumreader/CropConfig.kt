package com.eternumreader

import android.content.Context

object CropConfig {
    private const val PREFS = "crop"
    private const val L = "left"; private const val T = "top"
    private const val R = "right"; private const val B = "bottom"

    const val DEFAULT_LEFT = 0.05f
    const val DEFAULT_TOP = 0.67f
    const val DEFAULT_RIGHT = 0.95f
    const val DEFAULT_BOTTOM = 0.96f

    const val OCR_INTERVAL_MS = 900L
    const val STABLE_RESULTS_REQUIRED = 2
    const val MIN_TEXT_LENGTH = 2

    data class Rect(val left: Float, val top: Float, val right: Float, val bottom: Float)

    fun load(context: Context): Rect {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Rect(p.getFloat(L, DEFAULT_LEFT), p.getFloat(T, DEFAULT_TOP),
            p.getFloat(R, DEFAULT_RIGHT), p.getFloat(B, DEFAULT_BOTTOM))
    }

    fun save(context: Context, rect: Rect) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat(L, rect.left).putFloat(T, rect.top)
            .putFloat(R, rect.right).putFloat(B, rect.bottom).apply()
    }
}
