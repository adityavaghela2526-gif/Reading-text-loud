package com.eternumreader

import android.app.*
import android.content.*
import android.graphics.*
import android.media.*
import android.media.projection.*
import android.os.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class ReaderService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val EXTRA_RESULT_CODE="result_code"
        const val EXTRA_DATA="projection_data"
        private const val CHANNEL_ID="eternum_reader"
        private const val NOTIFICATION_ID=42
    }

    private lateinit var tts:TextToSpeech
    private val executor=Executors.newSingleThreadExecutor()
    private val running=AtomicBoolean(false)
    private var projection:MediaProjection?=null
    private var imageReader:ImageReader?=null
    private var lastProcessAt=0L
    private var lastStableText=""
    private var candidateText=""
    private var candidateCount=0

    override fun onCreate(){ super.onCreate(); createChannel(); tts=TextToSpeech(this,this) }

    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        val code=intent?.getIntExtra(EXTRA_RESULT_CODE,-1)?:-1
        val data=intent?.getParcelableExtra<Intent>(EXTRA_DATA)?:return START_NOT_STICKY
        val n=buildNotification("Watching Eternum dialogue")
        if(Build.VERSION.SDK_INT>=29) startForeground(NOTIFICATION_ID,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID,n)
        startProjection(code,data)
        return START_NOT_STICKY
    }

    private fun startProjection(code:Int,data:Intent){
        if(running.getAndSet(true))return
        val manager=getSystemService(MediaProjectionManager::class.java)
        projection=manager.getMediaProjection(code,data)
        val m=resources.displayMetrics
        imageReader=ImageReader.newInstance(m.widthPixels,m.heightPixels,PixelFormat.RGBA_8888,2)
        projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopReader()}},null)
        projection?.createVirtualDisplay("EternumReaderCapture",m.widthPixels,m.heightPixels,m.densityDpi,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,imageReader!!.surface,null,null)
        imageReader!!.setOnImageAvailableListener({reader->
            val now=SystemClock.elapsedRealtime()
            if(now-lastProcessAt<CropConfig.OCR_INTERVAL_MS){reader.acquireLatestImage()?.close();return@setOnImageAvailableListener}
            val image=try{reader.acquireLatestImage()}catch(_:Exception){null}?:return@setOnImageAvailableListener
            lastProcessAt=now
            executor.execute{processImage(image)}
        },null)
    }

    private fun processImage(image:Image){
        try{
            val bitmap=imageToBitmap(image)?:return
            val crop=cropBitmap(bitmap); bitmap.recycle()
            val input=InputImage.fromBitmap(crop,0)
            val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(input).addOnSuccessListener(executor){r->
                handleText(normalize(r.text)); crop.recycle(); recognizer.close()
            }.addOnFailureListener(executor){crop.recycle();recognizer.close()}
        }finally{image.close()}
    }

    private fun handleText(text:String){
        if(text.length<CropConfig.MIN_TEXT_LENGTH){candidateText="";candidateCount=0;return}
        if(text==candidateText)candidateCount++ else{candidateText=text;candidateCount=1}
        if(candidateCount>=CropConfig.STABLE_RESULTS_REQUIRED && text!=lastStableText){
            lastStableText=text
            tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"eternum_${SystemClock.uptimeMillis()}")
        }
    }

    private fun normalize(s:String)=s.replace(Regex("\s+")," ").replace("“",""").replace("”",""").trim()

    private fun cropBitmap(source:Bitmap):Bitmap{
        val r=CropConfig.load(this)
        val left=(source.width*r.left).toInt().coerceIn(0,source.width-1)
        val top=(source.height*r.top).toInt().coerceIn(0,source.height-1)
        val right=(source.width*r.right).toInt().coerceIn(left+1,source.width)
        val bottom=(source.height*r.bottom).toInt().coerceIn(top+1,source.height)
        return Bitmap.createBitmap(source,left,top,max(1,right-left),max(1,bottom-top))
    }

    private fun imageToBitmap(image:Image):Bitmap?{
        val plane=image.planes.firstOrNull()?:return null
        val bitmap=Bitmap.createBitmap(image.width+(plane.rowStride-plane.pixelStride*image.width)/plane.pixelStride,image.height,Bitmap.Config.ARGB_8888)
        bitmap.copyPixelsFromBuffer(plane.buffer)
        if(bitmap.width==image.width)return bitmap
        val c=Bitmap.createBitmap(bitmap,0,0,image.width,image.height);bitmap.recycle();return c
    }

    override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS){tts.language=Locale.US;tts.setSpeechRate(1f)}}
    private fun createChannel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL_ID,"Eternum Reader",NotificationManager.IMPORTANCE_LOW))}
    private fun buildNotification(text:String)=NotificationCompat.Builder(this,CHANNEL_ID).setContentTitle("Eternum Reader").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
    private fun stopReader(){if(!running.getAndSet(false))return;try{imageReader?.setOnImageAvailableListener(null,null)}catch(_:Exception){};try{imageReader?.close()}catch(_:Exception){};imageReader=null;try{projection?.stop()}catch(_:Exception){};projection=null}
    override fun onDestroy(){stopReader();try{tts.stop()}catch(_:Exception){};try{tts.shutdown()}catch(_:Exception){};executor.shutdownNow();super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
