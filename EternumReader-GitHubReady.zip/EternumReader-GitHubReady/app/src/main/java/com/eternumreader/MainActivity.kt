package com.eternumreader

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val captureRequest = 1001
    private val notificationRequest = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val info = TextView(this).apply {
            text = "Eternum Reader\n\nSelect the dialogue box once, then start.\n" +
                   "The selection is saved on the phone."
            textSize = 18f
            setPadding(30, 30, 30, 20)
        }
        val select = Button(this).apply {
            text = "1. Select dialogue area"
            setOnClickListener { showCropSelector() }
        }
        val start = Button(this).apply {
            text = "2. Start automatic reading"
            setOnClickListener { requestCapture() }
        }
        val stop = Button(this).apply {
            text = "Stop"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ReaderService::class.java))
                info.text = "Stopped."
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            addView(info, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(select, LinearLayout.LayoutParams(-1, 60))
            addView(start, LinearLayout.LayoutParams(-1, 60))
            addView(stop, LinearLayout.LayoutParams(-1, 60))
        })
    }

    private fun showCropSelector() {
        val dm = resources.displayMetrics
        val overlay = FrameLayout(this)
        overlay.setBackgroundColor(Color.argb(190, 0, 0, 0))

        val hint = TextView(this).apply {
            text = "Drag the box over Eternum's dialogue area, then tap SAVE"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(20, 20, 20, 20)
        }
        overlay.addView(hint, FrameLayout.LayoutParams(-1, 100, Gravity.TOP))

        val box = View(this)
        val drawable = GradientDrawable().apply {
            setColor(Color.argb(55, 255, 255, 255))
            setStroke(4, Color.WHITE)
        }
        box.background = drawable

        val saved = CropConfig.load(this)
        val lp = FrameLayout.LayoutParams(
            ((saved.right - saved.left) * dm.widthPixels).toInt().coerceAtLeast(80),
            ((saved.bottom - saved.top) * dm.heightPixels).toInt().coerceAtLeast(80)
        )
        lp.leftMargin = (saved.left * dm.widthPixels).toInt()
        lp.topMargin = (saved.top * dm.heightPixels).toInt().coerceAtLeast(110)
        overlay.addView(box, lp)

        var downX = 0f; var downY = 0f; var startLeft = 0; var startTop = 0
        box.setOnTouchListener { _, e ->
            val b = box.layoutParams as FrameLayout.LayoutParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX=e.rawX; downY=e.rawY; startLeft=b.leftMargin; startTop=b.topMargin; true
                }
                MotionEvent.ACTION_MOVE -> {
                    b.leftMargin=(startLeft+(e.rawX-downX)).toInt().coerceIn(0,dm.widthPixels-b.width)
                    b.topMargin=(startTop+(e.rawY-downY)).toInt().coerceIn(100,dm.heightPixels-b.height)
                    box.layoutParams=b; true
                }
                else -> true
            }
        }

        val save = Button(this).apply {
            text = "SAVE"
            setOnClickListener {
                val b = box.layoutParams as FrameLayout.LayoutParams
                CropConfig.save(this@MainActivity, CropConfig.Rect(
                    b.leftMargin.toFloat()/dm.widthPixels,
                    b.topMargin.toFloat()/dm.heightPixels,
                    (b.leftMargin+b.width).toFloat()/dm.widthPixels,
                    (b.topMargin+b.height).toFloat()/dm.heightPixels
                ))
                (overlay.parent as? android.view.ViewGroup)?.removeView(overlay)
            }
        }
        val saveLp = FrameLayout.LayoutParams(220,60,Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        saveLp.bottomMargin=30
        overlay.addView(save,saveLp)
        addContentView(overlay,FrameLayout.LayoutParams(-1,-1))
    }

    private fun requestCapture() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),notificationRequest)
        }
        val manager=getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(manager.createScreenCaptureIntent(),captureRequest)
    }

    @Deprecated("Minimal prototype")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=captureRequest || resultCode!=Activity.RESULT_OK || data==null) return
        ContextCompat.startForegroundService(this,Intent(this,ReaderService::class.java).apply {
            putExtra(ReaderService.EXTRA_RESULT_CODE,resultCode)
            putExtra(ReaderService.EXTRA_DATA,data)
        })
    }
}
