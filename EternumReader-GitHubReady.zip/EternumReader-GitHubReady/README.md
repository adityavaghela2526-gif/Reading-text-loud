# Eternum Reader

A minimal Android prototype that watches a selected Eternum dialogue rectangle, OCRs English/Latin text, detects new stable lines, and automatically speaks them with Android Text-to-Speech.

## Build remotely with GitHub Actions

1. Create a GitHub repository.
2. Upload the **contents** of this project, including `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab.
4. Choose **Build Eternum Reader APK**.
5. Tap **Run workflow**.
6. Wait for the green successful run.
7. Open that run and download the `EternumReader-debug-apk` artifact.
8. Extract it and install `app-debug.apk` on the Motorola.

GitHub Actions stores build output as downloadable workflow artifacts.

## Use

1. Open Eternum Reader.
2. Tap **Select dialogue area**.
3. Drag the rectangle over Eternum's dialogue box.
4. Tap **SAVE**.
5. Tap **Start automatic reading**.
6. Approve Android screen capture.
7. Return to Eternum.

The crop is saved locally, so it only needs to be selected again if the game layout changes.

## Behaviour

Eternum dialogue -> MediaProjection capture -> selected crop -> ML Kit OCR -> two matching OCR passes -> compare with previous spoken text -> Android TTS.

No OCR button or speaker button is needed during gameplay.

## Important

This is a debug prototype. The crop selector moves the rectangle but does not resize it. If the default rectangle size is not suitable, the current implementation needs a small selector enhancement to support corner resizing.

The app does not translate text. It only recognizes and speaks English/Latin text.
